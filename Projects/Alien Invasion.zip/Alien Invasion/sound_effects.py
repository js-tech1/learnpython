import pygame

pygame.mixer.init()

bullet_sound = pygame.mixer.Sound('sounds/laser.wav')
alien_sound = pygame.mixer.Sound('sounds/explosion.wav')
bg_sound = pygame.mixer.Sound('sounds/bg.wav')