students = [

    ('John', 'A', 2),
    ('Zoro', 'C', 1),
    ('Dave', 'B', 3),
]
print(sorted(students, key=lambda s : s[2]))

#starts from 0,1,2 for sorting in dictionaries